//20191396 ����� tictactoe practice 11

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <windows.h>
#include <time.h>
#include <conio.h>
#include <stdlib.h>


COORD playerScanCoord;

void putRandSeed() {
	srand((unsigned int)time(NULL));
}

void moveCursor(SHORT x, SHORT y)
{
	COORD coord;
	coord = { x , y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void printCenter(const char* str, int row, CONSOLE_SCREEN_BUFFER_INFO* csbi)
{
	int columns, rows;
	columns = csbi->srWindow.Right - csbi->srWindow.Left + 1;
	rows = csbi->srWindow.Bottom - csbi->srWindow.Top + 1;
	COORD coord = { (columns - strlen(str)) / 2 , row };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
	printf("%s", str);
}

void SetColor(SHORT x, SHORT y, int color)
{
	COORD coord;
	coord = { x , y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
	if (color == 1) SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_GREEN);
	else if (color == 2) SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE);
}
void drawCell(int n, SHORT x, SHORT y, int color)
{
	COORD coord;
	char str[6];
	SetColor(x, y, color);

	strcpy(str, "     ");
	printf("%s", str);
	SetColor(x, y + 1, color);

	strcpy(str, "  ");
	//if (color == 2) SetColor(x + 2, y + 1, 1);
	if (n == 1) strcat(str, "X");
	else if (n == 2) strcat(str, "O");
	else strcat(str, " ");
	strcat(str, "  ");

	printf("%s", str);
	SetColor(x, y + 2, color);
	strcpy(str, "     ");
	printf("%s", str);
	printf("\n");
}

void drawTTT(int a[][3], SHORT ypos, CONSOLE_SCREEN_BUFFER_INFO* csbi)
{
	int columns;

	columns = csbi->srWindow.Right - csbi->srWindow.Left + 1;
	SHORT center = (columns - 15) / 2;

	drawCell(a[0][0], center, ypos, 1);
	drawCell(a[0][1], center + 5, ypos, 2);
	drawCell(a[0][2], center + 10, ypos, 1);

	drawCell(a[1][0], center, ypos + 3, 2);
	drawCell(a[1][1], center + 5, ypos + 3, 1);
	drawCell(a[1][2], center + 10, ypos + 3, 2);

	drawCell(a[2][0], center, ypos + 6, 1);
	drawCell(a[2][1], center + 5, ypos + 6, 2);
	drawCell(a[2][2], center + 10, ypos + 6, 1);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
		FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	printCenter("Your turn:", ypos + 14, csbi);
	int consoleX;
	consoleX = csbi->srWindow.Right - csbi->srWindow.Left + 1;
	playerScanCoord = { (SHORT)((columns - strlen("Your turn:")) / 2 + 10) , (SHORT)(ypos + 14) };
}

int putN(int a[][3], int player, int row, int col)
{
	a[row][col] = player;
	return 1;
}
void playerPlay(int a[][3], int humanInt, CONSOLE_SCREEN_BUFFER_INFO& csbi)
{
	//���º� Ȯ��
	int count = 0;
	for (int i = 0; i < 9; i++)
	{
		if (a[i / 3][i % 3] != 0) count++;
	}
	if (count == 9)
	{
		return;
	}

	int t;
	fscanf_s(stdin, "%d", &t);
	while (!(t >= 1 && t <= 9 && a[(t - 1) / 3][(t - 1) % 3] == 0))
	{
		drawTTT(a, 7, &csbi);
		fscanf_s(stdin, "%d", &t);
	}
	getchar();
	a[(t - 1) / 3][(t - 1) % 3] = humanInt;

	drawTTT(a, 7, &csbi);
}

void comPlay(int a[][3], int aiselect, int comInt, int hInt, CONSOLE_SCREEN_BUFFER_INFO& csbi)
{
	const int delay = 500;

	printCenter("Computer is thinking..", 18, &csbi);
	Sleep(delay);
	int put = 0;
	//���º� Ȯ��
	int count = 0;
	for (int i = 0; i < 9; i++)
	{
		if (a[i / 3][i % 3] != 0) count++;
	}
	if (count == 9)
	{
		return;
	}

	//dumber
	if (aiselect == 1)
	{
		for (int i = 0; i < 9; i++)
		{
			if (a[i / 3][i % 3] == 0)
			{
				a[i / 3][i % 3] = comInt;
				drawTTT(a, 7, &csbi);
				return;
			}
		}
	}

	//dumb
	else if (aiselect == 2)
	{

		//com ���� 2�� Ȯ��
		for (int i = 0; i < 3; i++)
		{
			if (a[i][0] * a[i][1] == comInt * comInt && a[i][2] == 0)
			{
				put = putN(a, comInt, i, 1);
				break;
			}
			if (a[i][1] * a[i][2] == comInt * comInt && a[i][0] == 0)
			{
				put = putN(a, comInt, i, 1);
				break;
			}
			if (a[i][0] * a[i][2] == comInt * comInt && a[i][1] == 0)
			{
				put = putN(a, comInt, i, 1);
				break;
			}
		}

		//com ���� 2�� Ȯ��
		for (int i = 0; i < 3; i++)
		{
			if (a[0][i] * a[1][i] == comInt * comInt && a[2][i] == 0)
			{
				put = putN(a, comInt, 2, i);
				break;
			}
			if (a[1][i] * a[2][i] == comInt * comInt && a[0][i] == 0)
			{
				put = putN(a, comInt, 0, i);
				break;
			}
			if (a[0][i] * a[2][i] == comInt * comInt && a[1][i] == 0)
			{
				put = putN(a, comInt, 1, i);
				break;
			}
		}
		if (put == 1)
		{
			drawTTT(a, 7, &csbi);
			return;
		}
		//com �밢�� 2�� Ȯ��

		if (a[0][0] * a[1][1] == comInt * comInt && a[2][2] == 0) put = putN(a, comInt, 2, 2);
		if (a[1][1] * a[2][2] == comInt * comInt && a[0][0] == 0) put = putN(a, comInt, 0, 0);
		if (a[0][0] * a[2][2] == comInt * comInt && a[1][1] == 0) put = putN(a, comInt, 1, 1);
		if (a[2][0] * a[1][1] == comInt * comInt && a[0][2] == 0) put = putN(a, comInt, 0, 2);
		if (a[2][0] * a[0][2] == comInt * comInt && a[1][1] == 0) put = putN(a, comInt, 1, 1);
		if (a[0][2] * a[1][1] == comInt * comInt && a[0][2] == 0) put = putN(a, comInt, 0, 2);
		if (put == 1)
		{
			drawTTT(a, 7, &csbi);
			return;
		}

		//human ���� 2�� Ȯ��
		for (int i = 0; i < 3; i++)
		{
			if (a[i][0] * a[i][1] == hInt * hInt && a[i][2] == 0)
			{
				put = putN(a, comInt, i, 2);
				break;
			}
			if (a[i][1] * a[i][2] == hInt * hInt && a[i][0] == 0)
			{
				put = putN(a, comInt, i, 0);
				break;
			}
			if (a[i][0] * a[i][2] == hInt * hInt && a[i][1] == 0)
			{
				put = putN(a, comInt, i, 1);
				break;
			}
		}
		if (put == 1)
		{
			drawTTT(a, 7, &csbi);
			return;
		}

		//human ���� 2�� Ȯ��
		for (int i = 0; i < 3; i++)
		{
			if (a[0][i] * a[1][i] == hInt * hInt && a[2][i] == 0)
			{
				put = putN(a, comInt, 2, i);
				break;
			}
			if (a[1][i] * a[2][i] == hInt * hInt && a[0][i] == 0)
			{
				put = putN(a, comInt, 0, i);
				break;
			}
			if (a[0][i] * a[2][i] == hInt * hInt && a[1][i] == 0)
			{
				put = putN(a, comInt, 1, i);
				break;
			}
		}
		if (put == 1)
		{
			drawTTT(a, 7, &csbi);
			return;
		}

		//human �밢�� 2�� Ȯ��
		if (a[0][0] * a[1][1] == hInt * hInt && a[2][2] == 0) put = putN(a, comInt, 2, 2);
		if (a[1][1] * a[2][2] == hInt * hInt && a[0][0] == 0) put = putN(a, comInt, 0, 0);
		if (a[0][0] * a[2][2] == hInt * hInt && a[1][1] == 0) put = putN(a, comInt, 1, 1);
		if (a[2][0] * a[1][1] == hInt * hInt && a[0][2] == 0) put = putN(a, comInt, 0, 2);
		if (a[2][0] * a[0][2] == hInt * hInt && a[1][1] == 0) put = putN(a, comInt, 1, 1);
		if (a[0][2] * a[1][1] == hInt * hInt && a[0][2] == 0) put = putN(a, comInt, 0, 2);
		if (put == 1)
		{
			drawTTT(a, 7, &csbi);
			return;
		}

		//5
		if (a[1][1] == 0)
		{
			a[1][1] = comInt;
			drawTTT(a, 7, &csbi);
			return;
		}

		//2468
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				if ((i + j) % 2 == 1 && a[i][j] == 0)
				{
					a[i][j] = comInt;
					drawTTT(a, 7, &csbi);
					return;
				}
			}
		}
		//1379
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				if ((i + j) % 2 == 0 && a[i][j] == 0)
				{
					a[i][j] = comInt;
					drawTTT(a, 7, &csbi);
					return;
				}
			}
		}
		int t = rand() % 9;
		while (!(a[(t) / 3][(t) % 3] == 0))
		{
			drawTTT(a, 7, &csbi);
			t = rand() % 9;
		}
		a[(t) / 3][(t) % 3] = comInt;
		drawTTT(a, 7, &csbi);
		return;
	}
	//smart
	else if (aiselect == 3)
	{
		int scoreArr[3][3] = { 0, };
		int score = 0;
		int comCount = 0;
		int hCount = 0;

		//����
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				if (a[i][j] == comInt) comCount++;
				if (a[i][j] == hInt) hCount++;
			}
			for (int j = 0; j < 3; j++)
			{
				if (a[i][j] == 0)
				{
					if (comCount == 2 && hCount == 0) score = 1000;
					else if (comCount == 1 && hCount == 0) score = 15;
					else if (comCount == 0 && hCount == 2) score = 100;
					else if (comCount == 0 && hCount == 1) score = 10;
					else if (comCount == 0 && hCount == 0) score = 1;

					if (a[i][0] == 0)scoreArr[i][0] += score;
					if (a[i][1] == 0)scoreArr[i][1] += score;
					if (a[i][2] == 0)scoreArr[i][2] += score;
					break;
				}
			}
			comCount = 0;
			hCount = 0;
			score = 0;
		}

		//����
		comCount = 0;
		hCount = 0;
		score = 0;
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				if (a[j][i] == comInt) comCount++;
				if (a[j][i] == hInt) hCount++;
			}
			for (int j = 0; j < 3; j++)
			{
				if (a[i][j] == 0)
				{
					if (comCount == 2 && hCount == 0) score = 1000;
					else if (comCount == 1 && hCount == 0) score = 15;
					else if (comCount == 0 && hCount == 2) score = 100;
					else if (comCount == 0 && hCount == 1) score = 10;
					else if (comCount == 0 && hCount == 0) score = 1;

					if (a[0][i] == 0) scoreArr[0][i] += score;
					if (a[1][i] == 0)scoreArr[1][i] += score;
					if (a[2][i] == 0)scoreArr[2][i] += score;
					break;
				}
			}
			comCount = 0;
			hCount = 0;
			score = 0;
		}

		//�밢��
		comCount = 0;
		hCount = 0;
		score = 0;
		if (a[0][0] == 0 || a[1][1] == 0 || a[2][2] == 0)
		{
			for (int i = 0; i < 3; i++)
			{
				if (a[i][i] == comInt) comCount++;
				if (a[i][i] == hInt) hCount++;
			}

			if (comCount == 2 && hCount == 0) score = 1000;
			else if (comCount == 1 && hCount == 0) score = 15;
			else if (comCount == 0 && hCount == 2) score = 100;
			else if (comCount == 0 && hCount == 1) score = 10;
			else if (comCount == 0 && hCount == 0) score = 1;

			for (int i = 0; i < 3; i++)
			{
				if (a[i][i] == 0)
					scoreArr[i][i] += score;
			}
			comCount = 0;
			hCount = 0;
			score = 0;
		}

		comCount = 0;
		hCount = 0;
		score = 0;
		if (a[0][2] == 0 || a[1][1] == 0 || a[2][0] == 0)
		{
			for (int i = 0; i < 3; i++)
			{
				if (a[i][2 - i] == comInt) comCount++;
				if (a[i][2 - i] == hInt) hCount++;
			}

			if (comCount == 2 && hCount == 0) score = 1000;
			else if (comCount == 1 && hCount == 0) score = 15;
			else if (comCount == 0 && hCount == 2) score = 100;
			else if (comCount == 0 && hCount == 1) score = 10;
			else if (comCount == 0 && hCount == 0) score = 1;

			for (int i = 0; i < 3; i++)
			{
				if (a[i][2 - i] == 0)
					scoreArr[i][2 - i] += score;
			}
			comCount = 0;
			hCount = 0;
			score = 0;
		}


		//�ִ� ���ھ��� �� �� ����
		int selected = 0;
		int maxScore;
		int maxRow;
		int maxCol;
		for (int i = 0; i < 9; i++)
		{
			if (a[i / 3][i % 3] == 0) maxScore = scoreArr[i / 3][i % 3];
		}

		for (int i = 0; i < 9; i++)
		{
			if (a[i / 3][i % 3] == 0 && scoreArr[i / 3][i % 3] >= maxScore)
			{
				selected = 1;
				maxScore = scoreArr[i / 3][i % 3];
				maxRow = i / 3;
				maxCol = i % 3;
			}
		}
		if (selected == 1)
		{
			put = putN(a, comInt, maxRow, maxCol);
			if (put == 1)
			{
				drawTTT(a, 7, &csbi);
				return;
			}
		}
		int t = rand() % 9;
		while (!(a[(t) / 3][(t) % 3] == 0))
		{
			drawTTT(a, 7, &csbi);
			t = rand() % 9;
		}
		a[(t) / 3][(t) % 3] = comInt;
		drawTTT(a, 7, &csbi);
		return;
	}
}



int game(int select, int aiselect, const char* aiStr)
{
	int end = 0;
	char human, com;
	int humanInt, comInt;
	int randomCom = rand() % 3 + 1;
	char* randomComStr = NULL;
	if (randomCom == 1) randomComStr = (char*)"dumber";
	else if (randomCom == 2) randomComStr = (char*)"dumb";
	else if (randomCom == 3) randomComStr = (char*)"smart";

	if (aiselect == 0)
	{
		aiselect = rand() % 3 + 1;
		if (aiselect == 1) aiStr = "dumber";
		else if (aiselect == 2) aiStr = "dumb";
		else if (aiselect == 3) aiStr = "smart";
	}
	int a[3][3] = { 0, 0, 0,
					0, 0, 0,
					0, 0, 0 };
	//0: empty, 1: X, 2: O

	const int delay = 500;

	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);

	switch (select)
	{
	case 1:
		human = 'X';
		humanInt = 1;
		com = 'O';
		comInt = 2;
		break;
	case 2:
		human = 'O';
		humanInt = 2;
		com = 'X';
		comInt = 1;
		break;
	case 3:
		human = 'O';
		humanInt = 2;
		com = 'X';
		comInt = 1;
		break;
	case 0:
		exit(0);
		break;
	default:
		exit(0); //�׷��� �� �Լ� ������ select���� 0 ~ 4�� ��� ���� ����
		break;
	}



	char characterStr[100];
	if (select == 1 || select == 2) sprintf(characterStr, "You: %c, %s Computer: %c", human, aiStr, com);
	else if (select == 3) sprintf(characterStr, "%s Computer: %c, %s Computer: %c", aiStr, com, randomComStr, human);
	printCenter("### Tic-Tac-Toe ###", 2, &csbi);
	printCenter(characterStr, 4, &csbi);


	drawTTT(a, 7, &csbi);
	POINT p;
	GetCursorPos(&p);
	COORD inputCoord = { p.x, p.y };

	char msg[30];
	char again;
	const int msgY = 23;
	int t;


	int comSwitch = 0;
	if (select == 2)
	{
		comPlay(a, aiselect, comInt, humanInt, csbi);

		printCenter("                           ", 18, &csbi);
		moveCursor(playerScanCoord.X, playerScanCoord.Y);
	}

	while (true)
	{
		if (select == 1 || select == 2)
		{
			if (comSwitch == 0)
			{
				playerPlay(a, humanInt, csbi);
				comSwitch = 1;
			}
			else
			{
				comPlay(a, aiselect, comInt, humanInt, csbi);
				comSwitch = 0;
			}
			printCenter("                           ", 18, &csbi);
			moveCursor(playerScanCoord.X, playerScanCoord.Y);
		}
		else if (select == 3)
		{
			if (comSwitch == 0)
			{
				comPlay(a, aiselect, comInt, humanInt, csbi);
				comSwitch = 1;
			}
			else
			{
				comPlay(a, randomCom, humanInt, comInt, csbi);
				comSwitch = 0;
			}
			printCenter("                           ", 18, &csbi);
		}

		//���� �¸� ����
		for (int i = 0; i < 3; i++)
		{
			if (a[i][0] * a[i][1] * a[i][2] == humanInt * humanInt * humanInt)
			{
				sprintf(msg, "%c Win!", human);
				printCenter(msg, msgY, &csbi);
				end = 1;
				break;
			}
			else if (a[i][0] * a[i][1] * a[i][2] == comInt * comInt * comInt)
			{
				sprintf(msg, "%c Win!", com);
				printCenter(msg, msgY, &csbi);
				end = 1;
				break;
			}
		}

		if (end == 1)
		{
			printf("\n\nPlay again ? (Y/N): ");

			scanf("%c", &again);
			if (again == 'Y' || again == 'y') return 1;
			else return 0;
		}

		//���� �¸� ����
		for (int i = 0; i < 3; i++)
		{
			if (a[0][i] * a[1][i] * a[2][i] == humanInt * humanInt * humanInt)
			{
				sprintf(msg, "%c Win!", human);
				printCenter(msg, msgY, &csbi);
				end = 1;
				break;
			}
			if (a[0][i] * a[1][i] * a[2][i] == comInt * comInt * comInt)
			{
				sprintf(msg, "%c Win!", com);
				printCenter(msg, msgY, &csbi);
				end = 1;
				break;
			}
		}
		if (end == 1)
		{
			printf("\n\nPlay again ? (Y/N): ");

			scanf("%c", &again);
			if (again == 'Y' || again == 'y') return 1;
			else return 0;
		}

		//�밢�� �¸� ����
		if (a[0][0] * a[1][1] * a[2][2] == humanInt * humanInt * humanInt)
		{
			sprintf(msg, "%c Win!", human);
			printCenter(msg, msgY, &csbi);
			end = 1;
			break;
		}
		if (a[0][0] * a[1][1] * a[2][2] == comInt * comInt * comInt)
		{
			sprintf(msg, "%c Win!", com);
			printCenter(msg, msgY, &csbi);
			end = 1;
			break;
		}
		if (a[0][2] * a[1][1] * a[2][0] == humanInt * humanInt * humanInt)
		{
			sprintf(msg, "%c Win!", human);
			printCenter(msg, msgY, &csbi);
			end = 1;
			break;
		}
		if (a[0][2] * a[1][1] * a[2][0] == comInt * comInt * comInt)
		{
			sprintf(msg, "%c Win!", com);
			printCenter(msg, msgY, &csbi);
			end = 1;
			break;
		}

		//���º� ����
		int count = 0;
		for (int i = 0; i < 9; i++)
		{
			if (a[i / 3][i % 3] != 0) count++;
		}
		if (count == 9)
		{
			sprintf(msg, "Draw !");
			
			printCenter(msg, msgY, &csbi);
			end = 1;
			break;
		}

	}
	if (end == 1)
	{
		printf("\n\nPlay again ? (Y/N): ");

		scanf("%c", &again);
		if (again == 'Y' || again == 'y') return 1;
		else return 0;
	}
}

void AIMenu(int* aiselect, char*& str)
{
	printf("Enter the AI level (0: random, 1: dumber, 2: dumb, 3: smart):");

	scanf("%d", aiselect);
	while (*aiselect < 0 && *aiselect > 3)
	{
		scanf("%d", aiselect);
	}


	if (*aiselect == 0) str = (char*)"random";
	else if (*aiselect == 1) str = (char*)"dumber";
	else if (*aiselect == 2) str = (char*)"dumb";
	else if (*aiselect == 3) str = (char*)"smart";
}

void menu(int* select, const char* currentAI)
{
	printf("### Tic-Tac-Toe ###\n");
	printf("1 : Play first (X)\n");
	printf("2 : Play second (O)\n");
	printf("3 : Computer vs Computer\n");
	printf("4 : Select AI (current: %s)\n", currentAI);
	printf("0 : Exit\n");
	printf("Enter command:");
	scanf("%d", select);

}

int main()
{
	int select;

	int AISelect = 0;
	char* currentAI = (char*)"random";

	putRandSeed();
	while (true)
	{
		menu(&select, currentAI);

		while (select < 0 || select>4)
		{
			system("cls");
			menu(&select, currentAI);
		}

		if (select == 4)
		{
			AIMenu(&AISelect, currentAI);
			system("cls");
			continue;
		}
		if (select == 3) getchar();
		system("cls");
		if (game(select, AISelect, currentAI) == 1)
		{
			system("cls");
			continue;
		}
		else break;
	}

	return 0;
}