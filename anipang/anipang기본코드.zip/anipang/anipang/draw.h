#ifndef _DRAW_H
#define _DRAW_H

#include "anipang.h"

void gameStart(Board *board);
void display();

#endif